#include<stdio.h>
#include<stdlib.h> 
void main(){
    // we start with a 10-element array.
    int *array =  malloc(10*sizeof(int)); 
    // do something with array...
    // Expand it to a 20-element array. 
    array =  realloc(array, 20*sizeof(int)); 
    // free the heap memory of the NEW array! 
    free(array);
}