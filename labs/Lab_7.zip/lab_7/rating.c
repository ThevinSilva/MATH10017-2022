#include<stdio.h>
#include<stdlib.h> //must have!

void main(){
    printf("How many customers do we have today?\n");
    // read from keyboard, 
    int num_customers;
    scanf("%d", &num_customers);
    // allocate heap memory for an array 
    // depending on user's input
    int *pcustomer_ratings = 
            malloc(num_customers* sizeof(int) ); 
    
    // do something with the new array
    // e.g., initialize the array with ratings
    // then calculate the average score. 
    
    //release the heap memory
    free(pcustomer_ratings); 
}