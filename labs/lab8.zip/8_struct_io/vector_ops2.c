#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct vector{
    int len;
    int *elements; //pointing to the array
                    //stores elements of the vector.
};

void print(struct vector v){
    // v.len contains the length of the vector!
    for (int i=0; i<v.len; i++){ 
        printf("%d ", v.elements[i]);
    }
    printf("\n");
}

//TODO: define a function dot that takes two vector structure variables and returns the dot product of the two vectors.
// Your code here

int dot(struct vector v1, struct vector v2){
    int sum = 0;
    for(int i = 0; i<v1.len; i++){
        sum += v1.elements[i]*v2.elements[i];
    }
    return sum;
}


//TODO: define a function "norm" that takes a vector structure variable and returns the norm of the vector. 
// The norm of a vector is the square root of a dot a
// norm of [1,2,3] is square(a dot a)
// Hint: use the sqrt function from math.h
// Your code here

double norm(struct vector v){
    return sqrt(dot(v, v));
}

//TODO: define a function "dist" that takes two vector structure variables and returns the distance between the two vectors.
// The distance between two vectors is the norm of the difference of the two vectors.

double dist(struct vector u, struct vector v){
    struct vector diff;
    diff.len = u.len;
    diff.elements = malloc(diff.len*sizeof(int));
    for(int i = 0; i<diff.len; i++){
        diff.elements[i] = u.elements[i] - v.elements[i];
    }
    return norm(diff);
}

void main(){
    struct vector v; 
    v.len = 10; 
    // allocate heap memory for the vector
    v.elements = calloc(v.len, sizeof(int));

    // initialize the vector, using array initiliazation
    struct vector v2 = {10, calloc(10, sizeof(int))};

    // populate the vector with values 0,1,2,3,4,5,6,7,8,9
    for (int i=0; i<v.len; i++){
        v.elements[i] = i;
        v2.elements[i] = i;
    }

    print(v);
    print(v2);

    printf("______________________________\n");

    struct vector testu = {3, calloc(3, sizeof(int))};
    struct vector testv = {3, calloc(3, sizeof(int))};
    testu.elements[0] = 1; testu.elements[1] = 2; testu.elements[2] = 3; 
    testv.elements[0] = 4; testv.elements[1] = 5; testv.elements[2] = 6;
    print(testu); 
    print(testv);
    //TODO: test your functions here using u and v
    printf("dot product: %d. \n", dot(testu, testv));
    printf("norm: %.2f. \n", norm(testu));
    printf("dist: %.2f. \n", dist(testu, testv));

    //free the memory
    free(v.elements);
}