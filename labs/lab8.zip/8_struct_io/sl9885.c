#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// TODO: Define a matrix structure here.
struct matrix{
    int rows;
    int cols;
    int *elements;
};

int get_elem(struct matrix m, int row, int col){
    return m.elements[row*m.cols + col];
}  

void set_elem(struct matrix m, int row, int col, int val){
    m.elements[row*m.cols + col] = val;
}

void print(struct matrix m){
    for(int i = 0; i<m.rows; i++){
        for(int j = 0; j<m.cols; j++){
            printf("%d ", get_elem(m, i, j));
        }
        printf("\n");
    }
}

void add(struct matrix m1, struct matrix m2, struct matrix m3){
    for(int i = 0; i<m1.rows; i++){
        for(int j = 0; j<m1.cols; j++){
            set_elem(m3, i, j, get_elem(m1, i, j) + get_elem(m2, i, j));
        }
    }
}


void main(){
    int e1[] = {1,2,3,4,5,6};
    struct matrix m1 = {2, 3, e1};

    int e2[] = {7,8,9,10,11,12};
    struct matrix m2 = {2, 3, e2};

    int e3[] = {0,0,0,0,0,0};
    struct matrix m3 = {2, 3, e3};

    print(m1);

    add(m1, m2, m3);
    
    print(m2);
    print(m3);

}
